// Deterministic complete residue sieve. Bloom filters only add candidates.
// Reuses the previously checked recurrence and its coverage counters.
#define main original_multipass_main
#include "sieve_multipass.cpp"
#undef main
#include <cstdlib>
#include <cstring>
#include <memory>
#include <atomic>
#include <condition_variable>
#include <deque>
#include <exception>
#include <mutex>
#include <thread>

inline u64 mix(u64 x) {
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

struct Bloom {
    unsigned bits;
    u64 *words = nullptr, block_mask;
    explicit Bloom(unsigned b):bits(b),block_mask((1ULL<<b)-1) {
        if(b<1 || b>26) throw std::runtime_error("invalid Bloom size");
        size_t bytes = (1ULL<<b)*64;
        if(posix_memalign((void**)&words,64,bytes)) throw std::bad_alloc();
        std::memset(words,0,bytes);
    }
    ~Bloom(){std::free(words);}
    void prefetch(u64 h) {__builtin_prefetch(words+(h&block_mask)*8,1,1);}
    bool seen_and_insert_hash(u64 h) {
        u64 base=(h&block_mask)*8;
        unsigned a=(h>>bits)&511, b=(h>>(bits+9))&511, c=(h>>(bits+18))&511;
        u64 ma=1ULL<<(a&63),mb=1ULL<<(b&63),mc=1ULL<<(c&63);
        bool found=((words[base+(a>>6)]&ma)!=0) & ((words[base+(b>>6)]&mb)!=0) & ((words[base+(c>>6)]&mc)!=0);
        words[base+(a>>6)]|=ma; words[base+(b>>6)]|=mb; words[base+(c>>6)]|=mc;
        return found;
    }
};

struct CandidateSet {
    std::vector<u64> table;
    std::vector<uint8_t> seen;
    size_t mask;
    explicit CandidateSet(const std::vector<u64>& values, unsigned shift=0) {
        size_t cap=2;
        while(cap*0.7<values.size()) cap*=2;
        if(cap>(1ULL<<29)) throw std::runtime_error("candidate table too large; increase prefix_bits");
        table.resize(cap);mask=cap-1;
        for(u64 v:values) {
            // Residues are < P < UINT64_MAX, so v+1 is a nonzero exact encoding.
            size_t i=(mix(v)>>shift)&mask;
            while(table[i] && table[i]!=v+1)i=(i+1)&mask;
            table[i]=v+1;
        }
        seen.resize((cap+7)/8);
    }
    void prefetch(u64 h) {__builtin_prefetch(table.data()+(h&mask),0,1);}
    bool repeated_hash(u64 v,u64 h) {
        size_t i=h&mask;
        while(table[i] && table[i]!=v+1)i=(i+1)&mask;
        if(!table[i])return false;
        uint8_t m=1U<<(i&7);bool was=seen[i>>3]&m;seen[i>>3]|=m;
        return was;
    }
};


struct Item { u64 value, hash; };
struct Queue {
    std::mutex mutex;
    std::condition_variable ready;
    std::deque<std::vector<Item>> blocks;
    bool closed=false;
    std::atomic<bool>& stopped;
    explicit Queue(std::atomic<bool>& flag):stopped(flag){}
    void wake(){ready.notify_all();}
    void close(){ {std::lock_guard<std::mutex> guard(mutex);closed=true;} ready.notify_all(); }
    void push(std::vector<Item>&& block){
        std::unique_lock<std::mutex> lock(mutex);
        ready.wait(lock,[&]{return stopped.load()||blocks.size()<4;});
        if(stopped.load())throw std::runtime_error("parallel worker stopped");
        blocks.push_back(std::move(block));ready.notify_all();
    }
    bool pop(std::vector<Item>& block){
        std::unique_lock<std::mutex> lock(mutex);
        ready.wait(lock,[&]{return stopped.load()||closed||!blocks.empty();});
        if(stopped.load()||blocks.empty())return false;
        block=std::move(blocks.front());blocks.pop_front();ready.notify_all();return true;
    }
};

template<class Worker>
u64 parallel_pass(const Bounds& bounds,unsigned pb,unsigned prefix,unsigned rb,unsigned wb,
                  const char* phase,Worker worker){
    const unsigned workers=1U<<wb;
    const u64 mask=rb==64?UINT64_MAX:(1ULL<<rb)-1;
    std::atomic<bool> stopped(false);
    std::vector<std::unique_ptr<Queue>> queues;
    for(unsigned i=0;i<workers;++i)queues.emplace_back(new Queue(stopped));
    std::mutex error_mutex;std::exception_ptr error;
    std::vector<std::thread> threads;
    std::vector<u64> processed(workers);
    for(unsigned i=0;i<workers;++i)threads.emplace_back([&,i]{
        try{processed[i]=worker(i,*queues[i]);}
        catch(...){
            {std::lock_guard<std::mutex> guard(error_mutex);if(!error)error=std::current_exception();}
            stopped.store(true);for(auto& q:queues)q->wake();
        }
    });
    u64 selected=0;std::exception_ptr producer_error;
    try{
        std::vector<std::vector<Item>> buffers(workers);
        for(auto& b:buffers)b.reserve(4096);
        auto flush=[&](unsigned owner){
            queues[owner]->push(std::move(buffers[owner]));
            buffers[owner]=std::vector<Item>();buffers[owner].reserve(4096);
        };
        bounds.walk([&](u64 full,unsigned,unsigned){
            u64 v=full&mask;if(pb&&unsigned(v>>(rb-pb))!=prefix)return;
            u64 h=mix(v);unsigned owner=h&(workers-1);
            buffers[owner].push_back({v,h>>wb});++selected;
            if(buffers[owner].size()==4096)flush(owner);
            if(selected%500000000ULL==0)std::cerr<<"Partition "<<prefix+1<<'/'<<(1U<<pb)<<' '<<phase<<" progress "<<selected<<"\n";
        });
        for(unsigned i=0;i<workers;++i)if(!buffers[i].empty())flush(i);
    }catch(...){producer_error=std::current_exception();stopped.store(true);}
    for(auto& q:queues)q->close();
    for(auto& t:threads)t.join();
    if(error)std::rethrow_exception(error);
    if(producer_error)std::rethrow_exception(producer_error);
    u64 sum=0;for(u64 n:processed)sum+=n;
    if(sum!=selected)throw std::runtime_error("parallel coverage mismatch");
    return selected;
}

int main(int argc,char**argv){try{
    self_test();
    if(argc<3||argc>6)throw std::runtime_error("Usage: sieve_bloom bounds candidates.csv [prefix_bits=1] [block_bits=26] [residue_bits=64]");
    Bounds bounds(argv[1]);
    unsigned pb=argc>3?std::stoul(argv[3]):1, bb=argc>4?std::stoul(argv[4]):26;
    unsigned rb=argc>5?std::stoul(argv[5]):64;
    if(pb>16||rb<1||rb>64||pb>rb||bb<1||bb>26)throw std::runtime_error("invalid partition");
    unsigned passes=1U<<pb, wb=std::min(2U,bb-1), workers=1U<<wb;
    u64 rmask=rb==64?UINT64_MAX:(1ULL<<rb)-1;
    auto residue=[&](u64 v){return v&rmask;};
    auto start=std::chrono::steady_clock::now();
    auto seconds=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
    u64 total=0,potential_total=0;std::vector<u64> duplicates;
    std::cerr<<"Entries "<<bounds.count<<"; recurrence updates/pass "<<bounds.updates<<"; partitions "<<passes<<"; workers "<<workers<<"\n";
    for(unsigned prefix=0;prefix<passes;++prefix){
        constexpr size_t potential_limit=350000000ULL;
        std::vector<std::vector<u64>> potential(workers), repeated(workers);
        u64 selected=parallel_pass(bounds,pb,prefix,rb,wb,"filter",[&](unsigned owner,Queue& queue){
            auto& values=potential[owner];size_t cap=potential_limit/workers;
            values.reserve(std::min<u64>(cap,bounds.count));
            Bloom filter(bb-wb);std::vector<Item> block;u64 count=0;
            while(queue.pop(block)){
                for(size_t i=0;i<block.size();++i){
                    if(i+32<block.size())filter.prefetch(block[i+32].hash);
                    if(filter.seen_and_insert_hash(block[i].hash)){
                        if(values.size()>=cap)throw std::runtime_error("too many Bloom candidates; increase prefix_bits");
                        values.push_back(block[i].value);
                    }
                }
                count+=block.size();
            }
            return count;
        });
        u64 potential_count=0;for(const auto& v:potential)potential_count+=v.size();
        total+=selected;potential_total+=potential_count;
        std::cerr<<"Partition "<<prefix+1<<'/'<<passes<<"; selected "<<selected<<"; Bloom candidates "<<potential_count<<"; seconds "<<seconds()<<"\n";
        u64 replayed=parallel_pass(bounds,pb,prefix,rb,wb,"replay",[&](unsigned owner,Queue& queue){
            CandidateSet candidates(potential[owner],wb);std::vector<u64>().swap(potential[owner]);
            std::vector<Item> block;u64 count=0;
            while(queue.pop(block)){
                for(size_t i=0;i<block.size();++i){
                    if(i+32<block.size())candidates.prefetch(block[i+32].hash);
                    if(candidates.repeated_hash(block[i].value,block[i].hash))repeated[owner].push_back(block[i].value);
                }
                count+=block.size();
            }
            return count;
        });
        if(replayed!=selected)throw std::runtime_error("partition replay coverage mismatch");
        for(auto& v:repeated)duplicates.insert(duplicates.end(),v.begin(),v.end());
        std::cerr<<"Partition "<<prefix+1<<'/'<<passes<<" replayed; repeated residues "<<duplicates.size()<<"; seconds "<<seconds()<<"\n";
    }
    if(total!=bounds.count)throw std::runtime_error("partition coverage mismatch");
    std::sort(duplicates.begin(),duplicates.end());duplicates.erase(std::unique(duplicates.begin(),duplicates.end()),duplicates.end());
    std::vector<uint8_t> filter(1U<<17);
    for(u64 v:duplicates){unsigned h=mix(v)&((1U<<20)-1);filter[h>>3]|=1U<<(h&7);}
    struct Entry{u64 value;unsigned k,n;};std::vector<Entry> recovered;
    bounds.walk([&](u64 full,unsigned n,unsigned k){
        u64 v=residue(full);unsigned h=mix(v)&((1U<<20)-1);
        if((filter[h>>3]&(1U<<(h&7)))&&std::binary_search(duplicates.begin(),duplicates.end(),v))recovered.push_back({v,k,n});
    });
    std::sort(recovered.begin(),recovered.end(),[](const Entry&a,const Entry&b){if(a.value!=b.value)return a.value<b.value;if(a.k!=b.k)return a.k<b.k;return a.n<b.n;});
    std::ofstream out(argv[2]);out<<"a,b,x,y,residue\n";u64 count=0;
    for(size_t i=0;i<recovered.size();){
        size_t end=i+1;while(end<recovered.size()&&recovered[end].value==recovered[i].value)++end;
        for(size_t u=i;u<end;++u)for(size_t v=u+1;v<end;++v)if(recovered[u].k!=recovered[v].k){
            out<<recovered[u].k<<','<<recovered[v].k<<','<<recovered[u].n<<','<<recovered[v].n<<','<<recovered[u].value<<'\n';++count;
        }
        i=end;
    }
    out.flush();if(!out)throw std::runtime_error("candidate output failed");
    std::cout<<"{\"method\":\"deterministic_blocked_bloom_candidate_superset\",\"entries\":"<<bounds.count<<",\"max_row\":"<<bounds.N<<",\"updates_per_pass\":"<<bounds.updates<<",\"partitions\":"<<passes<<",\"recurrence_passes\":"<<2*passes+1<<",\"bloom_block_bits\":"<<bb<<",\"workers\":"<<workers<<",\"residue_bits\":"<<rb<<",\"bloom_candidates\":"<<potential_total<<",\"recovered_entries\":"<<recovered.size()<<",\"duplicate_residues\":"<<duplicates.size()<<",\"candidates\":"<<count<<",\"modulus\":\""<<P<<"\",\"seconds\":"<<seconds()<<"}\n";
    return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
