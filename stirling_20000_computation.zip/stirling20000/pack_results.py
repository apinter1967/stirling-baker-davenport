#!/usr/bin/env python3
"""Archive verified checkpoints, sources and completed result summaries."""
import argparse,hashlib,json,zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--base-archive',type=Path,help='Preserve existing archive members while overlaying verified local updates.')
args=parser.parse_args()
root=HERE/'run20000'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
sources={n:sha(HERE/n) for n in ('certify_bounds.py','verify_certificates.py')}
files=[];total=0;chunks=[]
for p in sorted(root.glob('*/completed.json')):
    c=json.loads(p.read_text());d=p.parent
    v=json.loads((d/'verification.json').read_text())
    assert c['source_sha256']==sources
    assert v['result']=='PASS' and v['precision_bits']==512
    assert c['verified_pairs']==v['verified_pairs']==sum(b-2 for b in range(c['b_start'],c['b_end']+1))
    assert sha(d/'column_bounds.txt.gz')==c['column_bounds_sha256']
    total+=c['verified_pairs'];chunks.append([c['b_start'],c['b_end']])
    for n in ('completed.json','verification.json','bounds_summary.json','column_bounds.txt.gz','generation.log','verification.log'):
        files.append(d/n)
status={'limit':20000,'verified_pairs':total,'target_pairs':199970001,'verified_chunks':chunks,
        'status':'REDUCTION IN PROGRESS; COMPLETE CLASSIFICATION NOT YET ESTABLISHED'}
if (root/'solutions.json').exists():
    result=json.loads((root/'solutions.json').read_text())
    assert result['status']=='COMPLETE' and result['limit']==20000 and total==199970001
    status['status']='COMPLETE';status['solutions']=result['solutions']
(HERE/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
files += sorted(p for p in HERE.glob('*.py') if p.name!='update_manuscript.py')+sorted(HERE.glob('*.cpp'))+[HERE/'STATUS.json']
for name in ('README.md','reduction.log','test100_sieve.json','test100_candidates.csv',
             'benchmark10000_sieve.json','benchmark10000_candidates.csv','benchmark10000_bounds.txt',
             'benchmark10000_verification.json'):
    p=HERE/name
    if p.exists() and p.stat().st_size:files.append(p)
for name in ('bounds_summary.json','aggregate_statistics.json','column_bounds.txt','production_build.json','sieve_summary.json','sieve.log','candidates.csv','solutions.json','final_check.log'):
    p=root/name
    if p.exists() and p.stat().st_size:files.append(p)
if (root/'production_build.json').exists():
    stage=root/json.loads((root/'production_build.json').read_text())['directory']
    for name in ('sieve_bloom.cpp','sieve_multipass.cpp','column_bounds.txt','build.json'):
        files.append(stage/name)
files += sorted((HERE/'sieve_tests').glob('*.json'))+sorted((HERE/'sieve_tests').glob('*.txt'))
out=HERE/'output/stirling_20000_computation.zip'
out.parent.mkdir(exist_ok=True)
members={}
if args.base_archive:
    with zipfile.ZipFile(args.base_archive) as z:
        assert z.testzip() is None
        for name in z.namelist():
            assert name.startswith('stirling20000/') and '..' not in Path(name).parts
            if not name.endswith('/') and name!='stirling20000/MANIFEST.sha256':
                members[name]=z.read(name)
for p in files:
    members['stirling20000/'+p.relative_to(HERE).as_posix()]=p.read_bytes()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    manifest=[]
    for name,data in sorted(members.items()):
        z.writestr(name,data)
        manifest.append(hashlib.sha256(data).hexdigest()+'  '+name)
    z.writestr('stirling20000/MANIFEST.sha256','\n'.join(manifest)+'\n')
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'verified_pairs':total,'status':status['status']}))
