#!/usr/bin/env python3
"""Inspect verified checkpoints and remove only already-verified temporaries."""
from pathlib import Path
import hashlib,json,shutil

HERE=Path(__file__).resolve().parent
root=HERE/'run20000'
total=0;ranges=[];removed=0
for p in sorted(root.glob('*/completed.json')):
    c=json.loads(p.read_text());d=p.parent
    v=json.loads((d/'verification.json').read_text())
    assert v['result']=='PASS' and v['verified_pairs']==c['verified_pairs']
    f=d/'column_bounds.txt.gz'
    assert hashlib.file_digest(f.open('rb'),'sha256').hexdigest()==c['column_bounds_sha256']
    total+=c['verified_pairs'];ranges.append((c['b_start'],c['b_end']))
    for f in [d/'bounds.csv',d/'certificates.jsonl.gz',d/'column_bounds.txt',
              *d.glob('.certificates.jsonl.gz.*'),*d.glob('.bounds.csv.*')]:
        if f.exists():removed+=f.stat().st_size;f.unlink(missing_ok=True)
through=2
for lo,hi in ranges:
    if lo!=through+1:break
    through=hi
print(json.dumps({'verified_pairs':total,'target_pairs':199970001,'percent':round(100*total/199970001,2),
                  'consecutive_through_b':through,'completed_chunks':len(ranges),
                  'removed_temporary_bytes':removed,'free_disk_gb':round(shutil.disk_usage(HERE).free/1e9,2)}))
