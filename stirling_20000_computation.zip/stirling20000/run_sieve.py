#!/usr/bin/env python3
"""Compile a frozen source snapshot and record the exact production run."""
import argparse,hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()

ap=argparse.ArgumentParser()
ap.add_argument('directory')
ap.add_argument('--prefix-bits',type=int,default=2)
ap.add_argument('--block-bits',type=int,default=26)
args=ap.parse_args();root=Path(args.directory).resolve()
meta=json.loads((root/'bounds_summary.json').read_text())
K=meta['limit'];assert meta['pairs']==(K-1)*(K-2)//2
stage=Path(tempfile.mkdtemp(prefix='sieve_run_',dir=root))
sources=('sieve_bloom.cpp','sieve_multipass.cpp')
for name in sources:shutil.copyfile(HERE/name,stage/name)
shutil.copyfile(root/'column_bounds.txt',stage/'column_bounds.txt')
source_hashes={name:sha(stage/name) for name in sources}
compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0]
subprocess.run(['g++','-O3','-std=c++17','-pthread',str(stage/'sieve_bloom.cpp'),'-o',str(stage/'sieve')],check=True)
build={'directory':stage.relative_to(root).as_posix(),'source_sha256':source_hashes,
       'input_sha256':sha(stage/'column_bounds.txt'),'binary_sha256':sha(stage/'sieve'),
       'compiler':compiler,'flags':['-O3','-std=c++17','-pthread'],
       'prefix_bits':args.prefix_bits,'block_bits':args.block_bits}
(stage/'build.json').write_text(json.dumps(build,indent=2)+'\n')
print('Frozen source and input directory:',stage.name,flush=True)
with (stage/'sieve_summary.json').open('w') as out,(stage/'sieve.log').open('w') as log:
    subprocess.run([str(stage/'sieve'),str(stage/'column_bounds.txt'),str(stage/'candidates.csv'),
                    str(args.prefix_bits),str(args.block_bits)],stdout=out,stderr=log,check=True)
sieve=json.loads((stage/'sieve_summary.json').read_text())
assert sieve['entries']==meta['column_entries'] and sieve['max_row']==meta['max_column_bound']
assert sieve['residue_bits']==64 and int(sieve['modulus'])==18446744073709551557
assert sha(root/'column_bounds.txt')==build['input_sha256']
assert {name:sha(stage/name) for name in sources}==source_hashes
build['candidate_sha256']=sha(stage/'candidates.csv')
build['summary_sha256']=sha(stage/'sieve_summary.json')
for name in ('candidates.csv','sieve_summary.json','sieve.log'):
    tmp=root/(name+'.new');shutil.copyfile(stage/name,tmp);os.replace(tmp,root/name)
(root/'production_build.json').write_text(json.dumps(build,indent=2)+'\n')
print(json.dumps(sieve,indent=2),flush=True)
