#!/usr/bin/env python3
"""Exercise many queue batches against an exact Python modular oracle."""
import csv, hashlib, json, subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
root=HERE/'sieve_tests';root.mkdir(exist_ok=True)
K=400;N=4000;P=18446744073709551557
bounds=root/'parallel_batches.txt'
bounds.write_text(str(K)+'\n'+' '.join(map(str,[0,0]+[N]*(K-1)))+'\n')
row=[0]*(K+1);row[0]=1
seen={};oracle=[];entries=0
for n in range(1,N+1):
    for k in range(min(n,K),0,-1):row[k]=(k*row[k]+row[k-1])%P
    row[0]=0
    for k in range(2,min(n-1,K)+1):
        v=row[k];entries+=1
        if v in seen:
            old=seen[v]
            if isinstance(old,tuple):old=[old];seen[v]=old
            for a,x in old:
                if a<k:oracle.append((a,k,x,n,v))
                elif k<a:oracle.append((k,a,n,x,v))
            old.append((k,n))
        else:seen[v]=(k,n)
del seen
out=root/'parallel_batches_candidates.csv'
cp=subprocess.run([str(HERE/'sieve_bloom'),str(bounds),str(out),'1','14'],check=True,capture_output=True,text=True)
got=sorted(tuple(int(r[k]) for k in ('a','b','x','y','residue')) for r in csv.DictReader(out.open()))
assert got==sorted(oracle)
summary=json.loads(cp.stdout)
assert summary['entries']==entries==1515801 and summary['workers']==4
report={'result':'PASS','oracle':'Python arbitrary-precision integer recurrence modulo P',
        'entries':entries,'candidates':len(got),'parallel':summary,
        'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(root/'parallel_batches_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
