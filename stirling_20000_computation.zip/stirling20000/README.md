# Certified Stirling computation for block numbers at most 20000

Read STATUS.json for the status of this version. A partial checkpoint is
not a complete classification. Completion requires run20000/solutions.json
with status COMPLETE and all 199970001 parameter pairs verified.

The equation is S(x,a)=S(y,b), where S denotes a Stirling number of the
second kind, 2<=a<b<=20000, x>a, and y>b. The row indices are unbounded
in advance. The manuscript proves the uniform initial bound x<10^30.

## Reproduction

Use a Linux/POSIX environment, Python 3.12, python-flint 0.9.0, and a C++17 compiler with unsigned
128-bit integer support. Do not run Python with -O: assertions implement
verification gates.

```sh
python3 -m pip install python-flint==0.9.0
python3 run_extension.py --limit 20000 --workers 8 --pairs-per-chunk 1000000 --output run20000
python3 run_sieve.py run20000 --prefix-bits 1 --block-bits 26
python3 check_extension_candidates.py run20000
```

For a fresh independent reproduction, use a directory without existing
run20000 checkpoints. Otherwise the driver validates and reuses completed
chunks. Generation uses 384-bit Arb balls, and a separate verifier checks
the certificate inequalities at 512 bits without generating continued
fractions. Both programs use Arb; they are not independent interval libraries.

Full certificate streams and pair tables are removed only after successful
replay and recording SHA-256 digests. Compressed column bounds, source hashes,
verification reports and generation summaries are retained. To inspect full
certificates, reproduce a selected interval separately:

```sh
python3 certify_bounds.py --limit 20000 --b-start 19953 --b-end 20000 --output audit
python3 verify_certificates.py audit
```

## Complete modular sieve

The recurrence is evaluated exactly modulo P=2^64-59. The source
sieve_bloom.cpp includes sieve_multipass.cpp to reuse its checked modular
recurrence and complete range traversal. Both source files are required.

A blocked Bloom filter records a superset of the repeated residues. It sets
three fixed bit positions for each residue and never clears a bit during a
partition pass. Thus every second occurrence is necessarily recorded.
Bit collisions only add candidates; no statistical assumption is used.
Within each pass, disjoint hash buckets are assigned to four workers. Every
occurrence of a residue is sent to the same worker in input order; each
worker owns its bit array and exact hash table. Coverage counters verify
that all queued entries were processed.

A second traversal determines which recorded residues occur at least twice
using an exact hash table. A final traversal recovers the coordinates of every repeated
residue. Every candidate in different columns is checked using additional
exact modular arithmetic and, when necessary, arbitrary-precision integers.

The production run uses all 64 residue bits. The reduced-bit option is only
for forced-collision tests; the final completion gate rejects that option.

```sh
g++ -O3 -std=c++17 -pthread sieve_bloom.cpp -o sieve_bloom
python3 test_sieve.py
python3 test_parallel_batches.py
```

The tests compare all candidates with an arbitrary-precision integer oracle,
including nonuniform column bounds, tiny filters, zero residues, deliberately
frequent collisions, and multiple partitions. The larger queue test compares 1,515,801 entries with a separate exact
Python modular recurrence. The retained benchmark10000_sieve.json records
a completed run of the earlier serial version on the 10000-column region;
it is not a timing measurement of the current parallel version.

Hashes provide integrity records, not mathematical proofs. The analytic
bound, certificate inequalities, complete traversal, and exact final checks
are the components of the computer-assisted classification.

## Completed calculation

All 199,970,001 parameter pairs were verified. The column union contains
14,831,749,739 entries. The complete sieve returned four candidates; exact
checks left precisely (a,b,x,y)=(2,5,5,6), (2,90,13,91), and
(11,363,14,364), with common values 15, 4095, and 66066.
The remaining modular collision was excluded modulo 1,000,000,007.
See run20000/solutions.json for the complete candidate audit.

This is a classification for 2<=a<b<=20000 with x>a and y>b, where the
row indices are unbounded in advance. It does not prove the unrestricted
three-value conjecture or a classification up to 100000.

## Frozen source records and independent final check

For a new run, run_sieve.py copies both C++ sources and the verified column
bounds to a unique staging directory before compilation. It records source,
input, binary and output digests in production_build.json. The final checker
validates the frozen source and output records as part of its completion gate.

The completed sieve in this package was imported from version 6 of the
shared computational archive. The actual archived sources and all column
bounds were checked against the local verified computation. All 199,970,001
local pair reductions had already passed 512-bit replay. The final completion
gate and candidate checks were then rerun locally against those checkpoints.
The production_build.json origin field identifies this imported run explicitly;
it does not claim a new local compilation or a binary digest for that run.
The source snapshot is retained in run20000/library_run_v6/.
