#!/usr/bin/env python3
"""Completion gate for the restartable parameter-bounded computation."""
import argparse
import csv
import gzip
import json
import math
from pathlib import Path
from run_extension import digest, HERE


def stirling_mod(n,k,p):
    assert p>k
    fact=[1]*(k+1)
    for j in range(1,k+1):fact[j]=fact[j-1]*j%p
    inv=[1]*(k+1);inv[k]=pow(fact[k],-1,p)
    for j in range(k,0,-1):inv[j-1]=inv[j]*j%p
    return sum((-1 if (k-j)%2 else 1)*pow(j,n,p)*inv[j]%p*inv[k-j]
               for j in range(k+1))%p


def stirling_exact(n,k):
    r=n-k
    if r==1:return n*(n-1)//2
    if r==2:return math.comb(n,3)+3*math.comb(n,4)
    if r==3:return math.comb(n,4)+10*math.comb(n,5)+15*math.comb(n,6)
    if n>10000:raise ArithmeticError('Large surviving candidate needs additional exact evaluation; completeness not certified')
    s=sum((-1)**(k-j)*math.comb(k,j)*pow(j,n) for j in range(k+1))
    q,r=divmod(s,math.factorial(k));assert r==0
    return q


def main():
    if not __debug__:raise SystemExit('Do not run with python -O')
    ap=argparse.ArgumentParser();ap.add_argument('directory');args=ap.parse_args()
    root=Path(args.directory)
    meta=json.loads((root/'bounds_summary.json').read_text())
    sieve=json.loads((root/'sieve_summary.json').read_text())
    K=meta['limit'];assert 3<=K<=100000
    sources={s:digest(HERE/s) for s in ('certify_bounds.py','verify_certificates.py')}
    assert sources==meta['source_sha256']
    U=[0]*(K+1);next_b=3;total=0
    for lo,hi in meta['chunks']:
        assert lo==next_b and lo<=hi<=K;next_b=hi+1
        d=root/f'b{lo:06d}_{hi:06d}'
        c=json.loads((d/'completed.json').read_text());v=json.loads((d/'verification.json').read_text())
        expected=sum(b-2 for b in range(lo,hi+1))
        assert c['limit']==K and c['b_start']==lo and c['b_end']==hi
        assert c['verified_pairs']==v['verified_pairs']==expected
        assert v['result']=='PASS' and v['precision_bits']==512
        assert c['source_sha256']==sources and c['column_bounds_sha256']==digest(d/'column_bounds.txt.gz')
        with gzip.open(d/'column_bounds.txt.gz','rt') as f:data=list(map(int,f.read().split()))
        assert data[0]==K and len(data)==K+2
        U=[max(x,y) for x,y in zip(U,data[1:],strict=True)];total+=expected
    assert next_b==K+1 and total==meta['pairs']==(K-1)*(K-2)//2
    assert list(map(int,(root/'column_bounds.txt').read_text().split()))==[K]+U
    entries=sum(max(0,U[k]-k) for k in range(2,K+1))
    assert entries==meta['column_entries']==sieve['entries']
    assert max(U)==meta['max_column_bound']==sieve['max_row']
    P=18446744073709551557;assert int(sieve['modulus'])==P
    build=json.loads((root/'production_build.json').read_text())
    assert build['input_sha256']==digest(root/'column_bounds.txt')
    assert build['candidate_sha256']==digest(root/'candidates.csv')
    assert build['summary_sha256']==digest(root/'sieve_summary.json')
    stage=root/build['directory']
    assert {s:digest(stage/s) for s in ('sieve_bloom.cpp','sieve_multipass.cpp')}==build['source_sha256']
    if sieve.get('method')=='deterministic_blocked_bloom_candidate_superset':
        assert sieve['residue_bits']==64
        assert sieve['recurrence_passes']==2*sieve['partitions']+1
    candidates=[{k:int(v) for k,v in row.items()} for row in csv.DictReader((root/'candidates.csv').open())]
    assert len(candidates)==sieve['candidates']
    assert len({tuple(c[k] for k in ('a','b','x','y')) for c in candidates})==len(candidates)
    audit=[];solutions=[]
    for c in candidates:
        a,b,x,y=(c[k] for k in ('a','b','x','y'))
        assert 2<=a<b<=K and a<x<=U[a] and b<y<=U[b]
        for p in (1000000007,1000000009):
            sx,sy=stirling_mod(x,a,p),stirling_mod(y,b,p)
            if sx!=sy:
                c.update(disposition='unequal by exact modular check',second_modulus=p,left_residue=sx,right_residue=sy)
                break
        else:
            sx,sy=stirling_exact(x,a),stirling_exact(y,b)
            assert sx%P==sy%P==c['residue']
            if sx==sy:
                c.update(disposition='exact equality',value=sx)
                solutions.append({k:c[k] for k in ('a','b','x','y','value')})
            else:c['disposition']='unequal by integer evaluation'
        audit.append(c)
    result={'status':'COMPLETE','limit':K,'verified_parameter_pairs':total,
            'modular_entries':entries,'solution_count':len(solutions),
            'solutions':solutions,'candidate_audit':audit,
            'sieve_source_sha256':build['source_sha256'],
            'sieve_source_directory':build['directory'],
            'sieve_summary_sha256':digest(root/'sieve_summary.json'),
            'candidate_file_sha256':digest(root/'candidates.csv')}
    (root/'solutions.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
