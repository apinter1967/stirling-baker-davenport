#!/usr/bin/env python3
"""Check the sieve against arbitrary-precision integers, forcing collisions."""
from pathlib import Path
import csv
import json
import subprocess

HERE=Path(__file__).resolve().parent
root=HERE/'sieve_tests';root.mkdir(exist_ok=True)
P=18446744073709551557
reports=[]
for label,U in [('ragged',[0,0,151,113,90,150,40,70,32,118,25,44,85]),
                ('small',[0,0,8,12,6,9,7,8])]:
    K=len(U)-1
    bounds=root/(label+'.txt')
    bounds.write_text(str(K)+'\n'+' '.join(map(str,U))+'\n')
    vals=[];row=[0]*(K+1);row[0]=1
    for n in range(1,max(U)+1):
        for k in range(min(n,K),0,-1):row[k]=k*row[k]+row[k-1]
        row[0]=0
        for k in range(2,K+1):
            if k<n<=U[k]:vals.append((row[k]%P,k,n))
    for rb in (8,64):
        groups={}
        for v,k,n in vals:groups.setdefault(v&((1<<rb)-1),[]).append((k,n))
        oracle=[]
        for v,g in groups.items():
            g.sort()
            for i,(a,x) in enumerate(g):
                for b,y in g[i+1:]:
                    if a!=b:oracle.append((a,b,x,y,v))
        oracle.sort()
        for pb,bb in [(0,1),(2,3)]:
            out=root/f'{label}_{rb}_{pb}.csv'
            cp=subprocess.run([str(HERE/'sieve_bloom'),str(bounds),str(out),str(pb),str(bb),str(rb)],check=True,capture_output=True,text=True)
            got=sorted(tuple(map(int,[r[k] for k in ['a','b','x','y','residue']])) for r in csv.DictReader(out.open()))
            assert got==oracle,(label,rb,pb,len(got),len(oracle))
            report=json.loads(cp.stdout);assert report['entries']==len(vals)
            reports.append({'fixture':label,'residue_bits':rb,'prefix_bits':pb,'bloom_block_bits':bb,
                            'entries':len(vals),'candidates':len(got),'result':'PASS'})
            out.unlink()
(root/'verification.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
