#!/usr/bin/env python3
"""Certified Baker--Davenport bounds for S(x,a)=S(y,b).

Requires python-flint (Arb real-ball arithmetic). No floating-point decision
is used for a mathematical inequality. See the accompanying manuscript.
"""
import argparse, csv, json, math, time, gzip
from pathlib import Path
from flint import arb, ctx

ctx.prec = 384
INITIAL_BOUND = 10**30

def floor_mid(z):
    return int(z.mid().floor().unique_fmpz())

def upper_integer(z):
    # An integer strictly above the upper endpoint (intentionally conservative).
    return int(z.upper().ceil().unique_fmpz()) + 1

def primitive_power(n):
    """Return c,r with n=c**r, c not a proper perfect power, by exact factoring."""
    fac = []
    t, p = n, 2
    while p*p <= t:
        e=0
        while t%p == 0:
            t//=p; e+=1
        if e: fac.append((p,e))
        p+=1
    if t>1: fac.append((t,1))
    r=0
    for p,e in fac: r=math.gcd(r,e)
    c=math.prod(p**(e//r) for p,e in fac)
    assert c**r==n
    return c,r

def approximant(tau,M):
    """CF is a search device; all needed properties are independently checked."""
    # Exact Euclidean algorithm on the dyadic midpoint is only a search device.
    # Every accepted approximation is checked against the full Arb interval.
    mantissa,exponent=tau.mid().man_exp()
    exponent=int(exponent)
    numerator=int(mantissa)<<max(exponent,0)
    denominator=1<<max(-exponent,0)
    p0,p1,q0,q1=0,1,1,0
    for _ in range(300):
        if not denominator: break
        h,remainder=divmod(numerator,denominator)
        p,q=h*p1+p0,h*q1+q0
        if q>8*M and M*abs(q*tau-p)<arb(1)/5:
            assert math.gcd(p,q)==1 and q>M
            return p,q
        p0,p1,q0,q1=p1,p,q1,q
        numerator,denominator=denominator,remainder
    raise ArithmeticError('No certified approximant at current precision')

def reduce_pair(a,b,logs,lfact,nn,powers):
    tau=logs[a]/logs[b]
    mu=(lfact[b]-lfact[a])/logs[b]
    beta=tau*(arb(b)/arb(b-1)).log()
    A=arb(2*(a+b))/logs[b]
    logA=A.log()
    X0=max(nn[a],upper_integer(arb(nn[b])/tau))
    c,r=powers[a]; d,s=powers[b]
    steps=[]
    if c==d:
        # a=c^r,b=c^s.  d=b!/a! is not a power of c (Bertrand's postulate).
        z=s*mu
        k=floor_mid(z+arb(1)/2)
        eta=abs(z-k)
        assert eta>0 and eta<arb(3)/5
        # k must really be a nearest integer; otherwise retry with exact distances.
        assert abs(z-k)<arb(1)/2 or (z-k).is_exact()
        bound=upper_integer((logA+arb(s).log()-eta.log())/beta)
        M=max(X0-1,bound)
        return M,X0,'dependent',[{'s':s,'nearest':k,'bound':M}]
    M=INITIAL_BOUND
    for _ in range(12):
        p,q=approximant(tau,M)
        R=floor_mid(q*mu+arb(1)/2)
        assert abs(q*mu-R)<arb(3)/5
        T=upper_integer((arb(5*q).log()+logA)/beta)
        assert beta*T>arb(5*q).log()+logA
        star=(-R*pow(p,-1,q))%q
        exception='outside'
        retain=0
        if T<=star<=M:
            ystar=(p*star+R)//q
            assert p*star-q*ystar+R==0
            L=abs(star*tau-ystar+mu)
            # This certified logarithmic comparison rejects the only possible
            # large exponent left by the integer-relation reduction lemma.
            if L>0 and L.log()+beta*star>logA:
                exception='rejected'
            else:
                exception='retained'
                retain=star
        newM=min(M,max(X0-1,T-1,retain))
        steps.append({'M':M,'p':str(p),'q':str(q),'R':str(R),
                      'T':T,'star':str(star),'exception':exception,'newM':newM})
        if newM==M: break
        M=newM
    return M,X0,'independent',steps

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--limit',type=int,default=100000)
    ap.add_argument('--output',default='run100000')
    ap.add_argument('--b-start',type=int,default=3)
    ap.add_argument('--b-end',type=int,default=None)
    args=ap.parse_args(); K=args.limit
    if not 3<=K<=100000: raise SystemExit('The proved uniform initial bound is for 3 <= K <= 100000.')
    first,last=args.b_start,args.b_end or K
    assert 3<=first<=last<=K
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    logs=[arb(0)]+[arb(k).log() for k in range(1,K+1)]
    lfact=[arb(0)]*(K+1)
    for k in range(1,K+1):lfact[k]=lfact[k-1]+logs[k]
    nn=[0,0]+[upper_integer(arb(2*k).log()/(arb(k)/arb(k-1)).log()) for k in range(2,K+1)]
    powers=[None,None]+[primitive_power(k) for k in range(2,K+1)]
    U=[0]*(K+1); counts={'independent':0,'dependent':0}
    maxima={'x_bound':0,'x_pair':None,'y_bound':0,'y_pair':None,'steps':0,'rejected_candidates':0}
    start=time.monotonic()
    with (out/'bounds.csv').open('w',newline='') as bf,gzip.open(out/'certificates.jsonl.gz','wt',compresslevel=1) as cf:
        writer=csv.writer(bf);writer.writerow(['a','b','x_bound','y_bound','threshold','branch'])
        for b in range(first,last+1):
            for a in range(2,b):
                M,X0,branch,steps=reduce_pair(a,b,logs,lfact,nn,powers)
                # Globally valid, including the small range x < X0:
                # b^(y-b) <= S(y,b)=S(x,a) <= a^x/a! <= a^x.
                Y=upper_integer(b+M*logs[a]/logs[b])
                U[a]=max(U[a],M);U[b]=max(U[b],Y)
                counts[branch]+=1
                writer.writerow([a,b,M,Y,X0,branch])
                cf.write(json.dumps({'a':a,'b':b,'branch':branch,'steps':steps},separators=(',',':'))+'\n')
                if M>maxima['x_bound']:maxima.update(x_bound=M,x_pair=[a,b])
                if Y>maxima['y_bound']:maxima.update(y_bound=Y,y_pair=[a,b])
                maxima['steps']=max(maxima['steps'],len(steps))
                maxima['rejected_candidates']+=sum(s.get('exception')=='rejected' for s in steps)
            if b%50==0:print(json.dumps({'through_b':b,'seconds':round(time.monotonic()-start,2),'max_x':maxima['x_bound']}),flush=True)
    with (out/'column_bounds.txt').open('w') as f:
        f.write(str(K)+'\n');f.write(' '.join(map(str,U))+'\n')
    summary={'limit':K,'b_start':first,'b_end':last,'pairs':sum(counts.values()),'counts':counts,'maxima':maxima,
             'precision_bits':ctx.prec,'initial_bound':str(INITIAL_BOUND),
             'column_entries':sum(max(0,U[k]-k) for k in range(2,K+1)),
             'max_column_bound':max(U),'elapsed_seconds':round(time.monotonic()-start,3)}
    (out/'bounds_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
