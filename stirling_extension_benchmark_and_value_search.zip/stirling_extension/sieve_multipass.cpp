// Complete deterministic residue sieve with bounded memory and no scratch buckets.
// Packed 48-bit fingerprints are sorted. A final pass recovers full residues.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
using u64=uint64_t;
constexpr u64 P=18446744073709551557ULL; // 2^64-59; primality is unnecessary.

inline u64 advance(unsigned k,u64 s,u64 prev){
    __uint128_t z=(__uint128_t)k*s+prev;
    u64 lo=(u64)z, hi=(u64)(z>>64), r=lo+59*hi;
    if(r<lo)r+=59;
    if(r>=P)r-=P;
    return r;
}

void self_test(){
    u64 state=17;
    auto rand64=[&](){state^=state<<13;state^=state>>7;state^=state<<17;return state;};
    for(unsigned k: {1U,2U,3U,9999U,10000U,99999U,100000U})
      for(u64 x:std::array<u64,5>{0,1,P-1,P-2,P/2})
        for(u64 y:std::array<u64,5>{0,1,P-1,P-2,P/2})
          if(advance(k,x,y)!=(u64)(((__uint128_t)k*x+y)%P))throw std::runtime_error("edge modular test failed");
    for(unsigned i=0;i<1000000;++i){
        unsigned k=1+rand64()%100000;u64 x=rand64()%P,y=rand64()%P;
        if(advance(k,x,y)!=(u64)(((__uint128_t)k*x+y)%P))throw std::runtime_error("random modular test failed");
    }
}

struct Bounds{
    unsigned K,N=0;u64 count=0,updates=0;
    std::vector<unsigned> U,suffix;
    explicit Bounds(const char*path){
        std::ifstream f(path);f>>K;
        if(!f||K<3||K>100000)throw std::runtime_error("invalid K");
        U.resize(K+1);suffix.resize(K+2);
        for(unsigned k=0;k<=K;++k){
            uint64_t v;f>>v;
            if(!f||v>UINT32_MAX)throw std::runtime_error("invalid row bound");
            U[k]=(unsigned)v;N=std::max(N,U[k]);
            if(k>=2&&U[k]>k)count+=U[k]-k;
        }
        std::string extra;if(f>>extra)throw std::runtime_error("extra bound entries");
        for(unsigned k=K;k>=1;--k)suffix[k]=std::max(U[k],suffix[k+1]);
        for(unsigned k=2;k<=K;++k)if(suffix[k]>=k)updates+=(u64)suffix[k]-k+1;
    }
    template<class F> u64 walk(F consume)const{
        std::vector<u64>S(K+1);S[1]=1;unsigned active=K;u64 visited=0;
        for(unsigned n=2;n<=N;++n){
            while(active>=2&&suffix[active]<n)--active;
            for(unsigned k=std::min(n,active);k>=2;--k){
                S[k]=advance(k,S[k],S[k-1]);
                if(n>k&&n<=U[k]){consume(S[k],n,k);++visited;}
            }
        }
        if(visited!=count)throw std::runtime_error("entry coverage mismatch");
        return visited;
    }
};

struct __attribute__((packed)) Fingerprint {uint32_t low;uint16_t high;};
static_assert(sizeof(Fingerprint)==6);
inline u64 key(Fingerprint f){return (u64)f.low+((u64)f.high<<32);}
void radix_sort(std::vector<Fingerprint>&a){
    if(a.empty())return;
    std::vector<Fingerprint>b(a.size());
    std::array<size_t,65536>c;
    for(unsigned shift=0;shift<48;shift+=16){
        c.fill(0);for(auto v:a)++c[(key(v)>>shift)&65535];
        size_t sum=0;for(auto&n:c){size_t old=n;n=sum;sum+=old;}
        for(auto v:a)b[c[(key(v)>>shift)&65535]++]=v;
        a.swap(b);
    }
    if(!std::is_sorted(a.begin(),a.end(),[](auto x,auto y){return key(x)<key(y);}))throw std::runtime_error("radix sort failed");
}

int main(int argc,char**argv){try{
    self_test();
    if(argc==2&&std::string(argv[1])=="--self-test"){std::cout<<"PASS\n";return 0;}
    if(argc<3||argc>5)throw std::runtime_error("Usage: sieve_multipass column_bounds.txt candidates.csv [prefix_bits] [fingerprint_bits]");
    Bounds bounds(argv[1]);
    unsigned bits=argc>=4?std::stoul(argv[3]):0;
    unsigned fingerprint_bits=argc==5?std::stoul(argv[4]):48;
    if(argc<4)while((bounds.count>>bits)>500000000ULL)++bits;
    if(bits>16||fingerprint_bits>48||fingerprint_bits<1||bits>fingerprint_bits)throw std::runtime_error("invalid partition");
    const u64 mask=(1ULL<<fingerprint_bits)-1;
    unsigned passes=1U<<bits;
    std::vector<u64>duplicates;
    auto start=std::chrono::steady_clock::now();u64 total=0;
    std::cerr<<"Entries "<<bounds.count<<"; recurrence updates/pass "<<bounds.updates<<"; passes "<<passes<<"\n";
    for(unsigned prefix=0;prefix<passes;++prefix){
        std::vector<Fingerprint>values;
        values.reserve((size_t)(bounds.count/passes+bounds.count/passes/20+100000));
        bounds.walk([&](u64 v,unsigned,unsigned){u64 f=v&mask;if(bits==0||(f>>(fingerprint_bits-bits))==prefix)values.push_back({(uint32_t)f,(uint16_t)(f>>32)});});
        radix_sort(values);
        for(size_t i=1;i<values.size();++i)if(key(values[i])==key(values[i-1])&&(duplicates.empty()||duplicates.back()!=key(values[i])))duplicates.push_back(key(values[i]));
        total+=values.size();
        std::cerr<<"Prefix "<<prefix+1<<'/'<<passes<<"; entries "<<values.size()<<"; duplicate fingerprints "<<duplicates.size()<<"; seconds "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
    }
    if(total!=bounds.count)throw std::runtime_error("prefix coverage mismatch");
    if(!std::is_sorted(duplicates.begin(),duplicates.end()))throw std::runtime_error("fingerprint order failed");
    // A bit filter may admit false positives but cannot reject a duplicated fingerprint.
    constexpr unsigned FILTER_BITS=24;
    std::vector<uint8_t>filter(1ULL<<(FILTER_BITS-3));
    for(u64 f:duplicates){unsigned h=f&((1U<<FILTER_BITS)-1);filter[h>>3]|=1U<<(h&7);}
    struct Entry{u64 value;unsigned k,n;};
    std::vector<Entry>recovered;
    bounds.walk([&](u64 v,unsigned n,unsigned k){
        u64 f=v&mask;unsigned h=f&((1U<<FILTER_BITS)-1);
        if((filter[h>>3]&(1U<<(h&7)))&&std::binary_search(duplicates.begin(),duplicates.end(),f))recovered.push_back({v,k,n});
    });
    std::sort(recovered.begin(),recovered.end(),[](const Entry&a,const Entry&b){if(a.value!=b.value)return a.value<b.value;if(a.k!=b.k)return a.k<b.k;return a.n<b.n;});
    std::ofstream out(argv[2]);out<<"a,b,x,y,residue\n";u64 candidates=0;
    u64 repeated_residues=0;
    for(size_t i=0;i<recovered.size();){
        size_t end=i+1;while(end<recovered.size()&&recovered[end].value==recovered[i].value)++end;
        if(end>i+1)++repeated_residues;
        for(size_t u=i;u<end;++u)for(size_t v=u+1;v<end;++v)if(recovered[u].k!=recovered[v].k){
            out<<recovered[u].k<<','<<recovered[v].k<<','<<recovered[u].n<<','<<recovered[v].n<<','<<recovered[u].value<<'\n';++candidates;
        }
        i=end;
    }
    out.flush();if(!out)throw std::runtime_error("candidate output failed");
    std::cout<<"{\"entries\":"<<bounds.count<<",\"max_row\":"<<bounds.N<<",\"updates_per_pass\":"<<bounds.updates<<",\"prefix_passes\":"<<passes<<",\"fingerprint_bits\":"<<fingerprint_bits<<",\"duplicate_fingerprints\":"<<duplicates.size()<<",\"recovered_entries\":"<<recovered.size()<<",\"duplicate_residues\":"<<repeated_residues<<",\"candidates\":"<<candidates<<",\"modulus\":\""<<P<<"\",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"}\n";
    return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
