#!/usr/bin/env python3
"""Replay certificates at 512 bits, without generating continued fractions.

This verifier checks the mathematical certificate conditions directly. The
uniform 10^30 bound is proved in the manuscript, not inferred from a search.
"""
import csv,json,math,sys,time,gzip
from pathlib import Path
from flint import arb,ctx
from certify_bounds import primitive_power

ctx.prec=512
root=Path(sys.argv[1]); meta=json.loads((root/'bounds_summary.json').read_text());K=meta['limit']
assert 3<=K<=100000
first,last=meta.get('b_start',3),meta.get('b_end',K)
expected_a,expected_b=2,first
powers=[None,None]+[primitive_power(k) for k in range(2,K+1)]
logs=[arb(0)]+[arb(k).log() for k in range(1,K+1)]
lf=[arb(0)]*(K+1)
for k in range(1,K+1):lf[k]=lf[k-1]+logs[k]
U=[0]*(K+1);verified=0;counts={'dependent':0,'independent':0};t=time.monotonic()
with (root/'bounds.csv').open() as bf,(gzip.open(root/'certificates.jsonl.gz','rt') if (root/'certificates.jsonl.gz').exists() else (root/'certificates.jsonl').open()) as cf:
  rows=csv.DictReader(bf)
  for row,line in zip(rows,cf,strict=True):
    cert=json.loads(line)
    a,b,X,Y,X0=(int(row[k]) for k in ('a','b','x_bound','y_bound','threshold'))
    assert (a,b)==(cert['a'],cert['b'])==(expected_a,expected_b) and 2<=a<b<=K
    verified+=1
    expected_a+=1
    if expected_a==b:expected_a,expected_b=2,b+1
    tau=logs[a]/logs[b];mu=(lf[b]-lf[a])/logs[b]
    ba=(arb(a)/arb(a-1)).log();bb=(arb(b)/arb(b-1)).log();beta=tau*bb
    # X0 implies both occupancy errors are at most 1/2, using y>tau*x.
    assert X0*ba>arb(2*a).log() and tau*X0*bb>arb(2*b).log()
    A=arb(2*(a+b))/logs[b];logA=A.log()
    ca,ra=powers[a];cb,rb=powers[b]
    if cert['branch']=='dependent':
      assert ca==cb and b>=2*a
      step,=cert['steps'];assert step['s']==rb
      z=rb*mu;eta=abs(z-step['nearest'])
      assert eta>0 and eta<arb(1)/2
      assert X>=X0-1 and X*beta>logA+arb(rb).log()-eta.log()
      assert X==step['bound']
    else:
      assert ca!=cb and cert['branch']=='independent'
      M=10**30
      for step in cert['steps']:
        assert step['M']==M
        p,q,R,T,star,newM=(int(step[k]) for k in ('p','q','R','T','star','newM'))
        assert q>M and math.gcd(p,q)==1
        assert M*abs(q*tau-p)<arb(1)/5
        assert abs(q*mu-R)<arb(3)/5
        assert beta*T>arb(5*q).log()+logA
        assert star==(-R*pow(p,-1,q))%q
        keep=0
        if T<=star<=M:
          y=(p*star+R)//q
          assert p*star-q*y+R==0
          if step['exception']=='rejected':
            L=abs(star*tau-y+mu)
            assert L>0 and L.log()+beta*star>logA
          else:
            assert step['exception']=='retained';keep=star
        else:assert step['exception']=='outside'
        assert newM==min(M,max(X0-1,T-1,keep))
        M=newM
      assert X==M
    assert row['branch']==cert['branch']
    assert Y>b+tau*X
    U[a]=max(U[a],X);U[b]=max(U[b],Y)
    counts[cert['branch']]+=1
    if verified%100000==0:print('Verified',verified,'pairs',flush=True)
assert (expected_a,expected_b)==(2,last+1)
assert verified==sum(b-2 for b in range(first,last+1))
data=list(map(int,(root/'column_bounds.txt').read_text().split()))
assert data[0]==K and data[1:]==U
result={'verified_pairs':verified,'branches':counts,'precision_bits':ctx.prec,
        'seconds':round(time.monotonic()-t,3),'result':'PASS'}
(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
