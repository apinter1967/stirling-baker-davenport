# Stirling computation: extension benchmark and exact value search

## Status

The classification for all block numbers a,b <= 100000 and unbounded row
indices has NOT been completed. Do not cite this archive as that result.
The completed parameter-bounded classification is a,b <= 20000.
Its full computation is supplied separately in stirling_20000_computation.zip;
this supplement contains the value search and the b=100000 benchmark.

This supplement contains two completed computations:

1. The entire b=100000 reduction slice, with 99998 parameter pairs, generated
   at 384 bits and independently replayed at 512 bits. This supplies finite
   search boxes, not solutions of the equations in those boxes.
2. A complete exact classification of all repeated Stirling values
   2 <= t <= 10^24, without a block-number restriction. The only repeated
   values are 15, 4095, and 66066, each with exactly two representations.
   Two different traversal implementations agree on all 1704385 enumerated
   entries, every diagonal cutoff, and the three triangular matches.

The updated manuscript proves the uniform initial bound x < 10^30 for
2 <= a < b <= 100000. The four-author reference is the published paper:
A. Bazsó, I. Mező, Á. Pintér and S. Tengely, International Journal of Number
Theory 21 (2025), no. 2, 257–269, DOI 10.1142/S1793042125500137.

## Reproduce the complete value search

Only the Python standard library is required:

```sh
python3 check_value_range.py --limit 1000000000000000000000000 --output value_range_1e24.json
python3 verify_value_range.py value_range_1e24.json
```

The excess-one diagonal consists of triangular numbers and is checked
symbolically. For excess r>=2, the inequalities G(k,r)>=k^4/8 and
G(k,r)>=2^(r+1)-1 prove that the enumeration is complete.
The first program traverses excesses and uses an exact dictionary.
The verifier traverses columns and sorts exact integers.

## Reproduce the completed reduction benchmark

Use Python 3.12 and python-flint 0.9.0. Do not enable Python's -O option.

```sh
python3 -m pip install python-flint==0.9.0
python3 certify_bounds.py --limit 100000 --b-start 100000 --b-end 100000 --output benchmark100000
python3 verify_certificates.py benchmark100000
```

The benchmark's full certificates and pair bounds are retained in this
archive. Their generator and verifier use the same Arb library; the verifier
uses higher precision and checks the acceptance conditions directly without
generating continued fractions.

## Full parameter-bounded pipeline (prepared, NOT completed at 100000)

The restartable driver splits the range into chunks of about 200000 pairs,
verifies each chunk before accepting it, and retains compressed column bounds
and SHA-256 digests. Full pair tables and certificate streams are removed
only after successful replay. They can be regenerated from the sources.

```sh
python3 run_extension.py --limit 100000 --workers 8 --output run100000
g++ -O3 -std=c++17 sieve_multipass.cpp -o sieve_multipass
./sieve_multipass run100000/column_bounds.txt run100000/candidates.csv > run100000/sieve_summary.json
python3 check_extension_candidates.py run100000
```

Rerun the first command to resume verified chunks. The driver does not
interpret a file merely existing as successful completion: it checks chunk
coverage, source hashes and compressed-bound hashes. The final checker
requires all chunks and the complete modular entry count before emitting
COMPLETE. A large unresolved surviving candidate stops the checker instead
of producing a completeness claim.

The complete pipeline was exercised at K=100 (test100), where it recovers
15 and 4095. No full K=100000 result is present.

## Resource assessment

The full K=100000 domain has 4999850001 parameter pairs. The measured
generation/replay rate at b=100000 extrapolates to about 28 hours on eight
cores, before additional setup and I/O overhead. This is an estimate only.

Even the union of column boxes from the single completed b=100000 slice
contains 327328299741 entries. Storing their packed six-byte fingerprints
would require 1963969798446 bytes (about 1.96 TB), before a sorting buffer.
The bounded-memory multipass sieve avoids this storage, but at the previous
500-million-entry-per-pass setting it requires 1024 full recurrence passes
for this union. The final sieve therefore requires substantially more
resources or a new algorithm; it has not been run for this slice or the full
100000-column domain.

The proposed unrestricted three-value statement is explicitly a conjecture.
The value cutoff 10^24 is a proved computational result, and must not be
confused with the unfinished 100000-column classification.
