#!/usr/bin/env python3
"""Replay the complete bounded-value search by increasing block number.

The generator traverses excesses and uses a dictionary. This verifier traverses
columns and uses an exact sort. Only excess-one values are handled symbolically.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('result')
    args = ap.parse_args()
    path = Path(args.result)
    claim = json.loads(path.read_text())
    T = claim['limit']
    start = time.monotonic()
    B = math.isqrt(math.isqrt(8*T))
    R = (T+1).bit_length()-2
    assert 2**(R+1)-1 <= T < 2**(R+2)-1
    assert B**4 <= 8*T < (B+1)**4
    h = [1]*(R+1)  # complete homogeneous polynomials in the single variable 1
    active = R
    values = []
    triangular = []
    counts = [0]*(R+1)
    maxk = [0]*(R+1)
    for k in range(2, B+1):
        for r in range(1, active+1):
            h[r] = h[r] + k*h[r-1]
            if h[r] > T:
                active = r-1
                break
            if r >= 2:
                values.append(h[r])
                counts[r] += 1
                maxk[r] = k
                d = math.isqrt(8*h[r]+1)
                if d*d == 8*h[r]+1:
                    n = (d+1)//2
                    triangular.append({'value': h[r], 'representations': sorted([[k+r,k],[n,n-1]])})
        if active < 2:
            break
    values.sort()
    # At the reported limit there are no collisions away from excess one.
    assert all(x < y for x,y in zip(values,values[1:]))
    assert len(values) == claim['enumerated_entries'] == claim['distinct_enumerated_values']
    expected = [{'excess':r, 'max_k':maxk[r], 'entries':counts[r]}
                for r in range(2,R+1) if counts[r]]
    assert expected == claim['diagonals']
    assert sorted(triangular, key=lambda x:x['value']) == claim['repeated_values']
    result = {'result':'PASS', 'limit':T, 'verified_entries':len(values),
              'traversal':'columns increasing, exact integer sort',
              'seconds':round(time.monotonic()-start,3),
              'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
              'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    path.with_name(path.stem+'_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
