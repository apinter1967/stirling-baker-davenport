#!/usr/bin/env python3
"""Restartable generation/replay up to 100000; never labels bounds a solution.

Full certificate streams and pair tables are hashed and removed only after
successful independent 512-bit replay. Compressed column bounds are retained.
"""
import argparse
import concurrent.futures
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def chunks(K, target):
    lo = 3
    while lo <= K:
        hi, count = lo, lo-2
        while hi < K and count+(hi-1) <= target:
            hi += 1
            count += hi-2
        yield lo, hi
        lo = hi+1


def main():
    if not __debug__:
        raise SystemExit('Do not run with python -O')
    ap = argparse.ArgumentParser()
    ap.add_argument('--limit', type=int, default=100000)
    ap.add_argument('--output', default='run100000')
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--pairs-per-chunk', type=int, default=200000)
    args = ap.parse_args()
    K = args.limit
    assert 3 <= K <= 100000 and args.workers >= 1 and args.pairs_per_chunk >= 1
    root = Path(args.output).resolve(); root.mkdir(parents=True, exist_ok=True)
    source_hashes = {s:digest(HERE/s) for s in ('certify_bounds.py','verify_certificates.py')}
    ranges = list(chunks(K,args.pairs_per_chunk))
    started = time.monotonic()

    def task(bounds):
        lo,hi = bounds
        d = root/f'b{lo:06d}_{hi:06d}'; d.mkdir(exist_ok=True)
        expected = sum(b-2 for b in range(lo,hi+1))
        done = d/'completed.json'
        if done.exists():
            c = json.loads(done.read_text())
            assert c['limit']==K and c['b_start']==lo and c['b_end']==hi
            assert c['verified_pairs']==expected and c['source_sha256']==source_hashes
            assert c['column_bounds_sha256']==digest(d/'column_bounds.txt.gz')
            return d
        for script, extra, log in (
            ('certify_bounds.py',['--limit',str(K),'--b-start',str(lo),'--b-end',str(hi),'--output',str(d)],'generation.log'),
            ('verify_certificates.py',[str(d)],'verification.log')):
            with (d/log).open('w') as stream:
                subprocess.run([sys.executable,str(HERE/script),*extra],stdout=stream,stderr=subprocess.STDOUT,check=True)
        v = json.loads((d/'verification.json').read_text())
        assert v['result']=='PASS' and v['precision_bits']==512 and v['verified_pairs']==expected
        hashes = {n:digest(d/n) for n in ('bounds.csv','certificates.jsonl.gz')}
        with gzip.open(d/'column_bounds.txt.gz','wb') as f:
            f.write((d/'column_bounds.txt').read_bytes())
        checkpoint = {'limit':K,'b_start':lo,'b_end':hi,'verified_pairs':expected,
            'source_sha256':source_hashes,'verified_stream_sha256':hashes,
            'column_bounds_sha256':digest(d/'column_bounds.txt.gz'),
            'retention':'Full pair tables and certificate streams removed after successful 512-bit replay; regenerate from source.'}
        temp = d/'completed.tmp';temp.write_text(json.dumps(checkpoint,indent=2)+'\n');temp.replace(done)
        for name in ('bounds.csv','certificates.jsonl.gz','column_bounds.txt'):
            (d/name).unlink()
        return d

    total = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(task,pair) for pair in ranges]
        for f in concurrent.futures.as_completed(futures):
            d = f.result();c=json.loads((d/'completed.json').read_text());total += c['verified_pairs']
            print(json.dumps({'verified_pairs':total,'target_pairs':(K-1)*(K-2)//2,
                              'seconds':round(time.monotonic()-started,2)}),flush=True)
    U = [0]*(K+1)
    next_b, merged = 3, 0
    for lo,hi in ranges:
        assert lo==next_b;next_b=hi+1
        d=root/f'b{lo:06d}_{hi:06d}'
        c=json.loads((d/'completed.json').read_text())
        assert c['source_sha256']==source_hashes and c['column_bounds_sha256']==digest(d/'column_bounds.txt.gz')
        with gzip.open(d/'column_bounds.txt.gz','rt') as f: data=list(map(int,f.read().split()))
        assert data[0]==K and len(data)==K+2
        U=[max(x,y) for x,y in zip(U,data[1:],strict=True)]
        merged+=c['verified_pairs']
    assert next_b==K+1 and total==merged==(K-1)*(K-2)//2
    (root/'column_bounds.txt').write_text(str(K)+'\n'+' '.join(map(str,U))+'\n')
    summary={'status':'ALL PAIR BOUNDS VERIFIED; EXACT SIEVE STILL REQUIRED',
        'limit':K,'pairs':total,'chunks':ranges,'source_sha256':source_hashes,
        'column_entries':sum(max(0,U[k]-k) for k in range(2,K+1)),
        'max_column_bound':max(U),'initial_bound':str(10**30),
        'generation_precision':384,'verification_precision':512,
        'seconds':round(time.monotonic()-started,3)}
    (root/'bounds_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='chunks'},indent=2))


if __name__=='__main__':
    main()
