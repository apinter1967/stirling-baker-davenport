#!/usr/bin/env python3
"""Exact, complete VALUE-bounded search, distinct from a block-bounded search.

Enumerate every nontrivial second-kind Stirling number <= T with excess >= 2.
The excess-one diagonal is tested symbolically by the triangular-number test.
No floating-point arithmetic or probabilistic sieve is used.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--limit', type=int, default=10**24)
    ap.add_argument('--output', default='value_range_1e24.json')
    args = ap.parse_args()
    T = args.limit
    if T < 2:
        raise SystemExit('limit must be at least 2')
    start = time.monotonic()
    # G(k,2) = k(k+1)(k+2)(3k+1)/24 >= k^4/8.
    B = math.isqrt(math.isqrt(8*T))
    previous = [k*(k+1)//2 for k in range(B+2)]
    seen = {}
    repeated = {}
    diagonals = []
    r = 2
    while True:
        current = [0, 1]  # G(0,r)=0 and G(1,r)=1.
        for k in range(2, len(previous)):
            value = k*previous[k] + current[-1]
            if value > T:
                break
            current.append(value)
            position = (k+r, k)
            if value in seen:
                old = seen[value]
                oldk, oldr = old & ((1 << 32)-1), old >> 32
                repeated.setdefault(value, {(oldk+oldr, oldk)}).add(position)
            else:
                seen[value] = (r << 32) | k
            disc = 1+8*value
            root = math.isqrt(disc)
            if root*root == disc:
                n = (1+root)//2
                assert n*(n-1)//2 == value and n >= 3
                repeated.setdefault(value, set()).update([position, (n, n-1)])
        count = len(current)-2
        if not count:
            assert 2**(r+1)-1 > T
            break
        diagonals.append({'excess': r, 'max_k': len(current)-1, 'entries': count})
        previous = current
        r += 1
    result = {
        'status': 'COMPLETE VALUE-BOUNDED CLASSIFICATION',
        'scope': 'All integers 2 <= t <= limit, all n > k >= 2; no block bound',
        'not_claimed': 'Classification with k <= 100000 and unbounded values',
        'limit': T, 'block_bound_for_excess_at_least_two': B,
        'enumerated_entries': sum(d['entries'] for d in diagonals),
        'distinct_enumerated_values': len(seen),
        'excess_one': 'Handled exactly by integer square root of 1+8*t',
        'diagonals': diagonals,
        'repeated_values': [
            {'value': t, 'representations': sorted(positions)}
            for t, positions in sorted(repeated.items())
        ],
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'elapsed_seconds': round(time.monotonic()-start, 3),
    }
    Path(args.output).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'diagonals'}, indent=2))


if __name__ == '__main__':
    main()
